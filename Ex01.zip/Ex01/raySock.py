from pyray import *
import json

SCREENWIDTH = 800
SCREENHEIGHT = 500
SCREEN_COLOR = GRAY
BOX_WIDTH = 80
BOX_HEIGHT = 30
DISTANCE_BOX = 15
NUM_FILE_IN_WIDTH = int((SCREENWIDTH-DISTANCE_BOX) / (BOX_WIDTH+DISTANCE_BOX))
DISTANCE_SIDE = int((SCREENWIDTH - (NUM_FILE_IN_WIDTH*BOX_WIDTH + (NUM_FILE_IN_WIDTH-1) * DISTANCE_BOX))/2)

class BOX:
	colorBox = BLACK
	colorText = WHITE
	def __init__(self, f, x, y, s):
		self.fileName = f
		self.posX = x
		self.posY = y
		self.size = s

def makeBox(box, name):
	countFile = 0
	curX = DISTANCE_SIDE
	curY = DISTANCE_BOX
	for file in name:
		temp = BOX(file['filename'], curX, curY, file['size'])
		box.append(temp)
		countFile += 1
		curX += BOX_WIDTH + DISTANCE_BOX
		if countFile % NUM_FILE_IN_WIDTH == 0:
			curX = DISTANCE_SIDE
			curY += BOX_HEIGHT + DISTANCE_BOX

def printBox(box):
	for num in range(len(box)):
		draw_rectangle(box[num].posX, box[num].posY, BOX_WIDTH, BOX_HEIGHT, box[num].colorBox)
		draw_text(box[num].fileName, box[num].posX + 20, box[num].posY + 10, 10, box[num].colorText)

def writeToFile(boxI):
	json_object = {'filename':boxI.fileName, 'size':boxI.size}	
	json_object_str = json.dumps(json_object, indent = 2)
	with open("input1.json", 'a') as f:
		f.write(json_object_str)

def checkMousePressed(box):
	posMouseX = get_mouse_x()
	posMouseY = get_mouse_y()
	for num in range(len(box)):
		if check_collision_point_rec((posMouseX, posMouseY), (box[num].posX, box[num].posY, BOX_WIDTH, BOX_HEIGHT)):
			box[num].colorBox = WHITE
			box[num].colorText = BLACK
			if is_mouse_button_pressed(0):
				writeToFile(box[num])
		else: 
			box[num].colorBox = BLACK
			box[num].colorText = WHITE

def makeFile(fileName):
	box = []
	makeBox(box, fileName)

	# window console
	init_window(SCREENWIDTH, SCREENHEIGHT, "Client")
	set_target_fps(60)	

	while not window_should_close():
		checkMousePressed(box)
		begin_drawing()
		clear_background(SCREEN_COLOR)
		printBox(box)
		end_drawing()
	
	close_window()