from pyray import *
import json

SCREENWIDTH = 800
SCREENHEIGHT = 500
SCREEN_COLOR = GRAY
BOX_WIDTH = 80
BOX_HEIGHT = 30
DISTANCE_BOX = 15
NUM_FILE_IN_WIDTH = int((SCREENWIDTH-DISTANCE_BOX) / (BOX_WIDTH+DISTANCE_BOX))
DISTANCE_SIDE = int((SCREENWIDTH - (NUM_FILE_IN_WIDTH*BOX_WIDTH + (NUM_FILE_IN_WIDTH-1) * DISTANCE_BOX))/2)

jsonArray = []

class BOX:
	colorBox = BLACK
	colorText = WHITE
	def __init__(self, f, x, y, s):
		self.fileName = f
		self.posX = x
		self.posY = y
		self.size = s

def makeBox(box, name):
	countFile = 0
	curX = DISTANCE_SIDE
	curY = DISTANCE_BOX
	for file in name:
		temp = BOX(file['filename'], curX, curY, file['size'])
		box.append(temp)
		countFile += 1
		curX += BOX_WIDTH + DISTANCE_BOX
		if countFile % NUM_FILE_IN_WIDTH == 0:
			curX = DISTANCE_SIDE
			curY += BOX_HEIGHT + DISTANCE_BOX

def printBox(box):
	for num in range(len(box)):
		draw_rectangle(box[num].posX, box[num].posY, BOX_WIDTH, BOX_HEIGHT, box[num].colorBox)
		draw_text(box[num].fileName, box[num].posX + 20, box[num].posY + 10, 10, box[num].colorText)

def writeToFile(boxI):
	global jsonArray
	json_object = {'filename':boxI.fileName, 'size':boxI.size}	
	jsonArray.append(json_object)
	with open("input.json", 'w') as f:
		json.dump(jsonArray, f, indent = 2)

def checkMousePressed(box):
	posMouseX = get_mouse_x()
	posMouseY = get_mouse_y()
	for num in range(len(box)):
		if check_collision_point_rec((posMouseX, posMouseY), (box[num].posX, box[num].posY, BOX_WIDTH, BOX_HEIGHT)):
			box[num].colorBox = WHITE
			box[num].colorText = BLACK
			if is_mouse_button_pressed(0):
				writeToFile(box[num])
		else: 
			box[num].colorBox = BLACK
			box[num].colorText = WHITE

def resizeImage(image, width, height):
	image_resize(image, width, height)
	texture = load_texture_from_image(image)
	return texture

def makeFile(fileName):
	box = []
	makeBox(box, fileName)

	# window console
	set_config_flags(FLAG_WINDOW_RESIZABLE);
	init_window(SCREENWIDTH, SCREENHEIGHT, "Client")
	set_trace_log_level(LOG_NONE)
	set_target_fps(60)	

	texture = load_texture("wall.png")
	image = load_image_from_texture(texture)
	curWidth = SCREENWIDTH
	curHeight = SCREENHEIGHT

	while not window_should_close():
		checkMousePressed(box)
		curWidth = get_screen_width()
		curHeight = get_screen_height()
		texture = resizeImage(image, curWidth, curHeight)
		begin_drawing()
		clear_background(SCREEN_COLOR)
		draw_texture_v(texture, [0, 0], WHITE)
		printBox(box)
		end_drawing()
	
	close_window()
