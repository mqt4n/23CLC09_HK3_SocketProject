# global variable in both file
def init():
	global announFirst
	global announSecond
	global downloading
	global endProgram

	announFirst = ''
	announSecond = ''
	downloading = False
	endProgram = False